for i in {0..10}
do
	./Linux_4.15.0-76-generic_x86_64.d/bins/unzzipcat-mem ./test/test.zip
	./Linux_4.15.0-76-generic_x86_64.d/bins/unzzipcat-mem ./test/test1.zip
	./Linux_4.15.0-76-generic_x86_64.d/bins/unzzipcat-mem ./test/test2.zip
	./Linux_4.15.0-76-generic_x86_64.d/bins/unzzipcat-mem ./test/test3.zip
done
