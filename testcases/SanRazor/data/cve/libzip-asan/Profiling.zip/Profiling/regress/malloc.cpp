
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchesmalloc);
extern uint64_t CCOUNT(numUCBranchesmalloc);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfomalloc)[], CCOUNT(SCBranchInfomalloc)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCmalloc)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfomalloc)[index].count[type];
}

void
CCOUNT(calledUCmalloc)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfomalloc)[index].count[0];
    CCOUNT(UCBranchInfomalloc)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfomalloc)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfomalloc)[index].count[2];
    }
}

void
CCOUNT(printSCmalloc)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/malloc_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/malloc_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesmalloc); ++id) {
            auto info = CCOUNT(SCBranchInfomalloc)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchesmalloc); ++id) {
            auto info = CCOUNT(SCBranchInfomalloc)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfomalloc)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfomalloc)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfomalloc)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/malloc_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesmalloc); ++id) {
            auto info = CCOUNT(SCBranchInfomalloc)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCmalloc)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/malloc_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/malloc_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesmalloc); ++id) {
            auto info = CCOUNT(UCBranchInfomalloc)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchesmalloc); ++id) {
            auto info = CCOUNT(UCBranchInfomalloc)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfomalloc)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfomalloc)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfomalloc)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/malloc_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesmalloc); ++id) {
            auto info = CCOUNT(UCBranchInfomalloc)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
