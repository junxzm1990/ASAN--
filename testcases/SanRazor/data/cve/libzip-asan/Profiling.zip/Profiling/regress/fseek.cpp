
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchesfseek);
extern uint64_t CCOUNT(numUCBranchesfseek);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfofseek)[], CCOUNT(SCBranchInfofseek)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCfseek)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfofseek)[index].count[type];
}

void
CCOUNT(calledUCfseek)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfofseek)[index].count[0];
    CCOUNT(UCBranchInfofseek)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfofseek)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfofseek)[index].count[2];
    }
}

void
CCOUNT(printSCfseek)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fseek_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fseek_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesfseek); ++id) {
            auto info = CCOUNT(SCBranchInfofseek)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchesfseek); ++id) {
            auto info = CCOUNT(SCBranchInfofseek)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfofseek)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfofseek)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfofseek)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fseek_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesfseek); ++id) {
            auto info = CCOUNT(SCBranchInfofseek)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCfseek)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fseek_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fseek_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesfseek); ++id) {
            auto info = CCOUNT(UCBranchInfofseek)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchesfseek); ++id) {
            auto info = CCOUNT(UCBranchInfofseek)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfofseek)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfofseek)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfofseek)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fseek_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesfseek); ++id) {
            auto info = CCOUNT(UCBranchInfofseek)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
