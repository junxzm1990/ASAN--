
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchesnonrandomopen);
extern uint64_t CCOUNT(numUCBranchesnonrandomopen);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfononrandomopen)[], CCOUNT(SCBranchInfononrandomopen)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCnonrandomopen)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfononrandomopen)[index].count[type];
}

void
CCOUNT(calledUCnonrandomopen)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfononrandomopen)[index].count[0];
    CCOUNT(UCBranchInfononrandomopen)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfononrandomopen)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfononrandomopen)[index].count[2];
    }
}

void
CCOUNT(printSCnonrandomopen)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/nonrandomopen_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/nonrandomopen_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesnonrandomopen); ++id) {
            auto info = CCOUNT(SCBranchInfononrandomopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchesnonrandomopen); ++id) {
            auto info = CCOUNT(SCBranchInfononrandomopen)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfononrandomopen)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfononrandomopen)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfononrandomopen)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/nonrandomopen_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesnonrandomopen); ++id) {
            auto info = CCOUNT(SCBranchInfononrandomopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCnonrandomopen)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/nonrandomopen_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/nonrandomopen_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesnonrandomopen); ++id) {
            auto info = CCOUNT(UCBranchInfononrandomopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchesnonrandomopen); ++id) {
            auto info = CCOUNT(UCBranchInfononrandomopen)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfononrandomopen)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfononrandomopen)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfononrandomopen)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/nonrandomopen_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesnonrandomopen); ++id) {
            auto info = CCOUNT(UCBranchInfononrandomopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
