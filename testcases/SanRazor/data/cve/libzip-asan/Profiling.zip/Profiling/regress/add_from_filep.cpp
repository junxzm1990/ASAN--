
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchesadd_from_filep);
extern uint64_t CCOUNT(numUCBranchesadd_from_filep);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfoadd_from_filep)[], CCOUNT(SCBranchInfoadd_from_filep)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCadd_from_filep)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfoadd_from_filep)[index].count[type];
}

void
CCOUNT(calledUCadd_from_filep)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfoadd_from_filep)[index].count[0];
    CCOUNT(UCBranchInfoadd_from_filep)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfoadd_from_filep)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfoadd_from_filep)[index].count[2];
    }
}

void
CCOUNT(printSCadd_from_filep)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/add_from_filep_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/add_from_filep_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesadd_from_filep); ++id) {
            auto info = CCOUNT(SCBranchInfoadd_from_filep)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchesadd_from_filep); ++id) {
            auto info = CCOUNT(SCBranchInfoadd_from_filep)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfoadd_from_filep)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfoadd_from_filep)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfoadd_from_filep)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/add_from_filep_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesadd_from_filep); ++id) {
            auto info = CCOUNT(SCBranchInfoadd_from_filep)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCadd_from_filep)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/add_from_filep_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/add_from_filep_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesadd_from_filep); ++id) {
            auto info = CCOUNT(UCBranchInfoadd_from_filep)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchesadd_from_filep); ++id) {
            auto info = CCOUNT(UCBranchInfoadd_from_filep)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfoadd_from_filep)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfoadd_from_filep)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfoadd_from_filep)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/add_from_filep_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesadd_from_filep); ++id) {
            auto info = CCOUNT(UCBranchInfoadd_from_filep)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
