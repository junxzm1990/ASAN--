
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchestryopen);
extern uint64_t CCOUNT(numUCBranchestryopen);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfotryopen)[], CCOUNT(SCBranchInfotryopen)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCtryopen)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfotryopen)[index].count[type];
}

void
CCOUNT(calledUCtryopen)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfotryopen)[index].count[0];
    CCOUNT(UCBranchInfotryopen)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfotryopen)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfotryopen)[index].count[2];
    }
}

void
CCOUNT(printSCtryopen)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/tryopen_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/tryopen_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchestryopen); ++id) {
            auto info = CCOUNT(SCBranchInfotryopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchestryopen); ++id) {
            auto info = CCOUNT(SCBranchInfotryopen)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfotryopen)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfotryopen)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfotryopen)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/tryopen_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchestryopen); ++id) {
            auto info = CCOUNT(SCBranchInfotryopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCtryopen)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/tryopen_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/tryopen_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchestryopen); ++id) {
            auto info = CCOUNT(UCBranchInfotryopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchestryopen); ++id) {
            auto info = CCOUNT(UCBranchInfotryopen)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfotryopen)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfotryopen)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfotryopen)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/tryopen_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchestryopen); ++id) {
            auto info = CCOUNT(UCBranchInfotryopen)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
