
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchesfopen_unchanged);
extern uint64_t CCOUNT(numUCBranchesfopen_unchanged);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfofopen_unchanged)[], CCOUNT(SCBranchInfofopen_unchanged)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCfopen_unchanged)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfofopen_unchanged)[index].count[type];
}

void
CCOUNT(calledUCfopen_unchanged)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfofopen_unchanged)[index].count[0];
    CCOUNT(UCBranchInfofopen_unchanged)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfofopen_unchanged)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfofopen_unchanged)[index].count[2];
    }
}

void
CCOUNT(printSCfopen_unchanged)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fopen_unchanged_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fopen_unchanged_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesfopen_unchanged); ++id) {
            auto info = CCOUNT(SCBranchInfofopen_unchanged)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchesfopen_unchanged); ++id) {
            auto info = CCOUNT(SCBranchInfofopen_unchanged)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfofopen_unchanged)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfofopen_unchanged)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfofopen_unchanged)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fopen_unchanged_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesfopen_unchanged); ++id) {
            auto info = CCOUNT(SCBranchInfofopen_unchanged)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCfopen_unchanged)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fopen_unchanged_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fopen_unchanged_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesfopen_unchanged); ++id) {
            auto info = CCOUNT(UCBranchInfofopen_unchanged)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchesfopen_unchanged); ++id) {
            auto info = CCOUNT(UCBranchInfofopen_unchanged)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfofopen_unchanged)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfofopen_unchanged)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfofopen_unchanged)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fopen_unchanged_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesfopen_unchanged); ++id) {
            auto info = CCOUNT(UCBranchInfofopen_unchanged)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
