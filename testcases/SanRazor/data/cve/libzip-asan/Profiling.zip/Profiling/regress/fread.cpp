
#include <cstdint>
#include <cstdio>

extern "C" {
#define CCOUNT(X) COUNTER_##X
extern uint64_t CCOUNT(numSCBranchesfread);
extern uint64_t CCOUNT(numUCBranchesfread);
extern struct {
    uint64_t id;
    uint64_t count[3];
} CCOUNT(UCBranchInfofread)[], CCOUNT(SCBranchInfofread)[], END;
struct BrInfo{
    uint64_t id;
    uint64_t count[3];
} ;
void
CCOUNT(calledSCfread)(uint64_t index, uint64_t type) {
    ++CCOUNT(SCBranchInfofread)[index].count[type];
}

void
CCOUNT(calledUCfread)(uint64_t index, bool cond) {
    ++CCOUNT(UCBranchInfofread)[index].count[0];
    CCOUNT(UCBranchInfofread)[index].id = index;
    if (cond) {
        ++CCOUNT(UCBranchInfofread)[index].count[1];
    }
    else {
        ++CCOUNT(UCBranchInfofread)[index].count[2];
    }
}

void
CCOUNT(printSCfread)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fread_SC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fread_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesfread); ++id) {
            auto info = CCOUNT(SCBranchInfofread)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numSCBranchesfread); ++id) {
            auto info = CCOUNT(SCBranchInfofread)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(SCBranchInfofread)[id].count[0] += info.count[0];
            CCOUNT(SCBranchInfofread)[id].count[1] += info.count[1];
            CCOUNT(SCBranchInfofread)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fread_SC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numSCBranchesfread); ++id) {
            auto info = CCOUNT(SCBranchInfofread)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}

void
CCOUNT(printUCfread)() {
    FILE *fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fread_UC.txt","rb");
    if (fp == NULL) {
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fread_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesfread); ++id) {
            auto info = CCOUNT(UCBranchInfofread)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
    else {
        for (size_t id = 0; id < CCOUNT(numUCBranchesfread); ++id) {
            auto info = CCOUNT(UCBranchInfofread)[id];
            fread(&info, sizeof(info), 1, fp);
            CCOUNT(UCBranchInfofread)[id].count[0] += info.count[0];
            CCOUNT(UCBranchInfofread)[id].count[1] += info.count[1];
            CCOUNT(UCBranchInfofread)[id].count[2] += info.count[2];
        }
        fp = fopen("/home/zhjiang/CVE/libzip-1.2.0/Cov/fread_UC.txt","wb");
        for (size_t id = 0; id < CCOUNT(numUCBranchesfread); ++id) {
            auto info = CCOUNT(UCBranchInfofread)[id];
            info.id = id;
            fwrite(&info,sizeof(info),1,fp);
        }
        fclose(fp);
    }
}
}
