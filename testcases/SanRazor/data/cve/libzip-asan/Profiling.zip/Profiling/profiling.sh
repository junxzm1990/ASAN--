for i in {0..3}
do
	./src/ziptool ./regress/streamed.zip cat index
	./src/ziptool ./regress/streamed-zip64.zip cat index
	./src/ziptool ./regress/test2.zip cat index
	./src/ziptool ./regress/testbuffer.zip cat index
	./src/ziptool ./regress/testchangedlocal.zip cat index
	./src/ziptool ./regress/testchanged.zip cat index
	./src/ziptool ./regress/testcomment13.zip cat index
	./src/ziptool ./regress/testcommentremoved.zip cat index
	./src/ziptool ./regress/testcomment.zip cat index
	./src/ziptool ./regress/test-cp437-comment-utf-8.zip cat index
	./src/ziptool ./regress/test-cp437-fc-utf-8-filename.zip cat index
	./src/ziptool ./regress/test-cp437-fc.zip cat index
	./src/ziptool ./regress/test-cp437.zip cat index
	./src/ziptool ./regress/testdeflated2.zip cat index
	./src/ziptool ./regress/testdeflated.zip cat index
	./src/ziptool ./regress/testdir.zip cat index
	./src/ziptool ./regress/testempty.zip cat index
	./src/ziptool ./regress/testextrabytes.zip cat index
	./src/ziptool ./regress/testfile2014.zip cat index
	./src/ziptool ./regress/testfile-cp437.zip cat index
	./src/ziptool ./regress/testfile-plus-extra.zip cat index
	./src/ziptool ./regress/testfile.txt
	./src/ziptool ./regress/testfile-UTF8.zip cat index
	./src/ziptool ./regress/testfile.zip cat index
	./src/ziptool ./regress/teststdin.zip cat index
	./src/ziptool ./regress/teststored.zip cat index
	./src/ziptool ./regress/test-utf8-unmarked.zip cat index
	./src/ziptool ./regress/test-utf8.zip cat index
	./src/ziptool ./regress/test.zip cat index
done
