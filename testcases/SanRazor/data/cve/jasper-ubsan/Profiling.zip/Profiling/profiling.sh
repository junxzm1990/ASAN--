#!/bin/bash
#set -e

#!/bin/bash
#set -e

path="./data/images/"
testfiles=$(ls $path)
for element in $testfiles
do
	echo $path$element
	./src/appl/imginfo -f $path$element 
done
