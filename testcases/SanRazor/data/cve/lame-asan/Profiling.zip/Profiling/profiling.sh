for i in {0..10}
do
	./frontend/lame -f -V 9 small.wav out.wav 
	./frontend/lame -f -V 9 testcase.mp3 out.wav
	./frontend/lame -f -V 9 testcase.wav out.wav
done
