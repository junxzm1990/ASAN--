#!/bin/bash
#set -e

cd tests
echo "runtest ......"
runtest &> /dev/null
runtest &> /dev/null
runtest &> /dev/null
cd ..
