for i in {1..10}
do
	utilities/gm convert -clip -negate lena-1bit-raw.sun out
	# utilities/gm convert -clip -negate lena-1bit-rle.sun out
	utilities/gm convert -clip -negate lena-24bit-raw.sun out
	# utilities/gm convert -clip -negate lena-24bit-rle.sun out
	utilities/gm convert -clip -negate lena-8bit-raw.sun out
	# utilities/gm convert -clip -negate lena-8bit-rle.sun out
done
